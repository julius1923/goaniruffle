# GoAnimate4Schools Revival
This is an API wrapper for GoAnimate4Schools, which was shut down in June of 2019.
## How to Use
To access this service, install [Node.JS](https://nodejs.org/en/) then clone/download this project.	Once done, unzip the folder, copy the path, and execute the following commands in your command prompt (where `{PATH}` is the folder path you copied):
```console
cd {PATH}
npm install
npm start
```
**When done, go to your web browser and navigate to `localhost`.**
